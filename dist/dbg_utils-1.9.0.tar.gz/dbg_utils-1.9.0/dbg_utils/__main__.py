from dbg_utils.idp_server import idpss

idpss.start()

